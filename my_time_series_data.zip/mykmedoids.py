import numpy as np
import random

def initCentroids(Dis_matrix,K):
    numSamples = len(Dis_matrix) 
    v = np.zeros([numSamples,1])
    for j in range(0,numSamples):
        vi = 0
        for i in range(0,numSamples):
            temp = Dis_matrix[i,j]/sum(Dis_matrix[i,:])
            vi = vi+temp
        v[j] = vi
    mylist = np.argsort(v, axis=0)
    centroids_id = mylist[0:K]            
    return centroids_id 

def kMedoids(D, k, tmax=10000,init_centroids=1 ):
    # determine dimensions of distance matrix D
    m, n = D.shape

    if k > n:
        raise Exception('too many medoids')

    # find a set of valid initial cluster medoid indices since we
    # can't seed different clusters with two points at the same location
    valid_medoid_inds = set(range(n))
    invalid_medoid_inds = set([])
    rs,cs = np.where(D==0)
    # the rows, cols must be shuffled because we will keep the first duplicate below
    index_shuf = list(range(len(rs)))
    np.random.shuffle(index_shuf)
    rs = rs[index_shuf]
    cs = cs[index_shuf]
    for r,c in zip(rs,cs):
        # if there are two points with a distance of 0...
        # keep the first one for cluster init
        if r < c and r not in invalid_medoid_inds:
            invalid_medoid_inds.add(c)
    valid_medoid_inds = list(valid_medoid_inds - invalid_medoid_inds)

    if k > len(valid_medoid_inds):
        raise Exception('too many medoids (after removing {} duplicate points)'.format(
            len(invalid_medoid_inds)))

    # randomly initialize an array of k medoid indices
#    M = np.array(valid_medoid_inds)
#    np.random.shuffle(M)
#    M = np.sort(M[:k])
    if init_centroids ==1:
    #init centroids
        v = np.zeros([m,1])
        for j in range(0,m):
            vi = 0
            for i in range(0,m):
                temp = D[i,j]/sum(D[i,:])
                vi = vi+temp
            v[j] = vi
        mylist = np.argsort(v, axis=0)
        M = mylist[0:k]   
         
    else:
    #ramdom init 
        M = np.array(valid_medoid_inds)
        np.random.shuffle(M)
        M = np.sort(M[:k])


    # create a copy of the array of medoid indices
    Mnew = np.copy(M)

    # initialize a dictionary to represent clusters
    C = {}
    for t in range(tmax):
        # determine clusters, i. e. arrays of data indices
        J = np.argmin(D[:,M], axis=1)
        for kappa in range(k):
            C[kappa] = np.where(J==kappa)[0]
        # update cluster medoids
        for kappa in range(k):
            J = np.mean(D[np.ix_(C[kappa],C[kappa])],axis=1)
            j = np.argmin(J)
            Mnew[kappa] = C[kappa][j]
        np.sort(Mnew)
        # check for convergence
        if np.array_equal(M, Mnew):
            break
        M = np.copy(Mnew)
    else:
        # final update of cluster memberships
        J = np.argmin(D[:,M], axis=1)
        for kappa in range(k):
            C[kappa] = np.where(J==kappa)[0]
            
    label = np.zeros([1,m])
    for key in C:
        label[0,C[key]] = key
    
    label = label.T   

    # return results
#    return M, C, label
    return label


    
    
    
    
    
    
    
    
    