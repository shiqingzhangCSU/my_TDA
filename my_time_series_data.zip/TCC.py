#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 15:52:05 2020

@author: csu302
"""


import numpy as np



def temporal_corrlation_sim( x , y ):   #temporal correlation coefficient

    temp1 = [x[k] - x[k-1] for k in range(1,len(x))]
    temp2 = [y[k] - y[k-1] for k in range(1,len(y))]
    vector_1 = np.mat(temp1)
    vector_2 = np.mat(temp2)
    num = float(vector_1 * vector_2.T)
    denom = np.linalg.norm(vector_1) * np.linalg.norm(vector_2)
    TCC = num/denom
    return TCC

def adj_fucyion(x,k):
    temp = 1 + np.exp(k*x)
    y = 2/temp
    return y
    