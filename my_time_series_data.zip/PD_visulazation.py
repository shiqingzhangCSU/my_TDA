#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 11:10:32 2020

@author: csu302
"""

import numpy as np 
from ripser import ripser
from persim import plot_diagrams
import matplotlib.pyplot as plt 

dgm0 = ripser(data000.T)['dgms'][1]

plt.figure(figsize=(6, 6))
plot_diagrams(dgm0)
plt.title("Persistence Diagram")
plt.savefig('PD2.png', dpi=600)
plt.clf()