#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 15:20:48 2020

@author: csu302
"""
import numpy as np 
import pandas as pd 
import os
import math 
import matplotlib.pyplot as plt 
from ripser import ripser
from persim import plot_diagrams,bottleneck,sliced_wasserstein
import sklearn_tda
from sklearn_tda import *
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA

def takensEmbedding (data, delay, dimension):
    "This function returns the Takens embedding of data with delay into dimension, delay*dimension must be < len(data)"
    if delay*dimension > len(data):
        raise NameError('Delay times dimension exceed length of data!')    
    embeddedData = np.array([data[0:len(data)-delay*dimension]])
    for i in range(1, dimension):
        embeddedData = np.append(embeddedData, [data[i*delay:len(data) - delay*(dimension - i)]], axis=0)
    return embeddedData;

def adaptive_tuning_1(x,k):
    temp = 1 + np.exp(k*(1-2*x))
    y = 2/temp
    return y

def adaptive_tuning_2(x,k):
    temp = 1 + np.exp(-k*x)
    y = 2/temp
    return y

def adaptive_tuning_3(x,k):
    y = np.log(k*x+2)
    return y

def timeseries_tda ( data,m= 10 ,delay = 2 ,H = 1 , distance="wasserstein", adaptive_tuning=3 , K=2):
    "input: data, H is the dimensiong of homology , K is the paramiter of the adjust function"
    time_feature = data
    point_N = np.size(data,0) #unit number
    time_interval = np.size(data,1)
    
    embedded_time_feature = {}
    diagrams = {}
    
    for i in range(0,point_N):   
        
        dimension = m  
        Hi = H       
        embedded_time_feature[i] = takensEmbedding(time_feature[i,:], delay, dimension)
        pca = PCA(n_components=2)    
        embedded_time_feature[i] = pca.fit(embedded_time_feature[i].T).transform(embedded_time_feature[i].T)
        
        dgm0 = ripser(embedded_time_feature[i])['dgms'][Hi]
        dgm0[ np.isinf(dgm0)] = 0  
        if Hi==1:     
            dgm0 = np.append(dgm0,[[0,  0]], axis=0)    #padding                
        diagrams[i] = dgm0
        
    bottleneck_dis = np.zeros((point_N,point_N))
    wasserstein_dis = np.zeros((point_N,point_N))  
    
    if distance =="wasserstein":
        for i in range(0,point_N):
            for j in range (i,point_N):    
                wasserstein_dis[i][j] = sliced_wasserstein(diagrams[i], diagrams[j])
                wasserstein_dis[j][i] = wasserstein_dis[i][j]    
        tda_dis = wasserstein_dis
                
         
    if distance =="bottleneck":
        for i in range(0,point_N):
            for j in range (i,point_N):           
                bottleneck_dis[i][j] = bottleneck(diagrams[i], diagrams[j])    
                bottleneck_dis[j][i] = bottleneck_dis[i][j]
        tda_dis = bottleneck_dis
        
    if adaptive_tuning==1:
        ss = MinMaxScaler()
        tda_dis = ss.fit_transform(tda_dis)
        tda_dissimilar = adaptive_tuning_1(tda_dis,K)
    
    if adaptive_tuning==2:
        ss = MinMaxScaler()
        tda_dis = ss.fit_transform(tda_dis)
        tda_dissimitive_tuning_2(tda_dis,K)
        
    if adaptive_tuning==3:
        ss = MinMaxScaler()
        tda_dis = ss.fit_transform(tda_dis)
        tda_dissimilar = adaptive_tuning_3(tda_dis,K)
        
    if adaptive_tuning==0:
        tda_dissimilar = tda_dis
    
    
    return tda_dissimilar
        
        
        
        

