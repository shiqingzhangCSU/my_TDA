#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 11:46:32 2020

@author: csu302
"""

import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score,homogeneity_score
from sklearn.metrics import completeness_score,adjusted_mutual_info_score,fowlkes_mallows_score
from dtw import *
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import TDATS
import TCC
from sklearn.cluster import AgglomerativeClustering

data1 = np.loadtxt('/home/csu302/taxi_data/UCR_time_series/chinatown_train.csv',delimiter=',')
data2 = np.loadtxt('/home/csu302/taxi_data/UCR_time_series/chinatown_test.csv',delimiter=',')
data_all = np.concatenate((data1,data2),axis=0)

x = data_all[:,1:]
y = data_all[:,0]
k = 2

index = ['PCA+kmeans','DTW_Kmediods','tda']
columns = ['ARS','AMI','HS','CS']
result = np.zeros((20,10), dtype = float, order = 'C')


#kmeans+PCA
pca = PCA(n_components=10)
x_r = pca.fit(x).transform(x)
y_KMeans = KMeans(n_clusters=k, random_state=2020).fit_predict(x_r)

result_pca = adjusted_rand_score(y,y_KMeans)
#result[0][1] = adjusted_mutual_info_score(y,y_KMeans)
#result[0][2] = homogeneity_score(y,y_KMeans)
#result[0][3] = completeness_score(y,y_KMeans)
#result[0][4] = fowlkes_mallows_score(y,y_KMeans)

#Eucliden distance
point_N = len(x) # unit number
E_dis = np.zeros([point_N,point_N]) #distance matrix
for i in range(0,point_N):
    for j in range (i,point_N):
        temp = x[i,:] - x[j,:]
        E_dis[i,j]=np.linalg.norm(temp)
        E_dis[j,i] = E_dis[i,j]
        
clustering = AgglomerativeClustering(n_clusters=k, affinity='precomputed',linkage='average')
clustering.fit(E_dis)
label_E = clustering.labels_        
result_E = adjusted_rand_score(y,label_E)
#result[1][1] = adjusted_mutual_info_score(y,label_E.tolist()[0])
#result[1][2] = homogeneity_score(y,label_E.tolist()[0])
#result[1][3] = completeness_score(y,label_E.tolist()[0])
#result[1][4] = fowlkes_mallows_score(y,label_E.tolist()[0])




#DTW
point_N = len(x) # unit number
DTW_dis = np.zeros([point_N,point_N]) #distance matrix
for i in range(0,point_N):
    for j in range (i,point_N):
        alignment = dtw(x[i,:],x[j,:])
        DTW_dis[i,j] = alignment.distance
        DTW_dis[j,i] = DTW_dis[i,j]

clustering.fit(DTW_dis)
labelDTW = clustering.labels_        
result_DTW = adjusted_rand_score(y,labelDTW)
#result[2][1] = adjusted_mutual_info_score(y,labelDTW)
#result[2][2] = homogeneity_score(y,labelDTW)
#result[2][3] = completeness_score(y,labelDTW)
#result[2][4] = fowlkes_mallows_score(y,labelDTW)



#DTW+CORRELATION
#
cor_coeffient = np.zeros([point_N,point_N]) #temporal correlation coefficient

for i in range(0,point_N):
    for j in range (0,point_N):
        cor_coeffient[i][j] = TCC.temporal_corrlation_sim(x[i,:],x[j,:])

cor_sim =TCC.adj_fucyion(cor_coeffient,k=0.5)
dtw_cor_distance = DTW_dis*cor_sim
clustering.fit(dtw_cor_distance)
label_cor = clustering.labels_
result_cor = adjusted_rand_score(y,label_cor)
#result[3][1] = adjusted_mutual_info_score(y,label_cor.tolist()[0])
#result[3][2] = homogeneity_score(y,label_cor.tolist()[0])
#result[3][3] = completeness_score(y,label_cor.tolist()[0])
#result[3][4] = fowlkes_mallows_score(y,label_cor.tolist()[0])

#DTW+TDA
for i in range(3,20):
    for j in[1,2,3]:    
        tda_dissim = TDATS.timeseries_tda(x, m = i , delay = j, H=1, distance ="wasserstein", adaptive_tuning=1 ,K=1)
        dtw_tda_distance = DTW_dis*tda_dissim
        clustering.fit(dtw_tda_distance)
        label_tda = clustering.labels_
        result[i][j] = adjusted_rand_score(y,label_tda)
#        result[i][j][1] = adjusted_mutual_info_score(y,label2.tolist()[0])
#        result[i][j][2] = homogeneity_score(y,label2.tolist()[0])
#        result[i][j][3] = completeness_score(y,label2.tolist()[0])
#        result[i][j][4] = fowlkes_mallows_score(y,label2.tolist()[0])
