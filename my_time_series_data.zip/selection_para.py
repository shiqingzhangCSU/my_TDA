#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 09:59:55 2020

@author: csu302
"""

import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score,homogeneity_score
from sklearn.metrics import completeness_score,adjusted_mutual_info_score,fowlkes_mallows_score
from dtw import *
from mykmedoids import kMedoids,initCentroids
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import TDATS
import TCC
from sklearn.cluster import AgglomerativeClustering

data1 = np.loadtxt('/home/csu302/taxi_data/UCR_time_series/synthetic_control/synthetic_control_TRAIN',delimiter=',')
data2 = np.loadtxt('/home/csu302/taxi_data/UCR_time_series/synthetic_control/synthetic_control_TEST',delimiter=',')
data_all = np.concatenate((data1,data2),axis=0)

x = data1[:,1:]
y = data1[:,0]
k = 6

#result = np.zeros((20,40), dtype = float, order = 'C')
#result1 = np.zeros((20,40), dtype = float, order = 'C')

#Eucliden distance
point_N = len(x) # unit number
E_dis = np.zeros([point_N,point_N]) #distance matrix
for i in range(0,point_N):
    for j in range (i,point_N):
        temp = x[i,:] - x[j,:]
        E_dis[i,j]=np.linalg.norm(temp)
        E_dis[j,i] = E_dis[i,j]
        
clustering_E = AgglomerativeClustering(n_clusters=k, affinity='precomputed',linkage='average')
clustering_E.fit(E_dis)
label_E = clustering_E.labels_      
result_DTW = adjusted_rand_score(y,label_E)

#result[1][1] = adjusted_mutual_info_score(y,label_E.tolist()[0])
#result[1][2] = homogeneity_score(y,label_E.tolist()[0])
#result[1][3] = completeness_score(y,label_E.tolist()[0])
#result[1][4] = fowlkes_mallows_score(y,label_E.tolist()[0])


#
#
#DTW
point_N = len(x) # unit number
DTW_dis = np.zeros([point_N,point_N]) #distance matrix
for i in range(0,point_N):
    for j in range (i,point_N):
        alignment = dtw(x[i,:],x[j,:])
        DTW_dis[i,j] = alignment.distance
        DTW_dis[j,i] = DTW_dis[i,j]
       
clustering_DTW = AgglomerativeClustering(n_clusters=k, affinity='precomputed',linkage='average')
clustering_DTW.fit(DTW_dis)
label_DTW = clustering_DTW.labels_      
result_DTW = adjusted_rand_score(y,label_DTW)

result = np.zeros((20,40), dtype = float, order = 'C')
for dimension in range(2,11):
    for delay in range(1,5): 
        alpha = 0.025
        tda_dissim = TDATS.timeseries_tda(x, m = dimension, delay = delay, H=1, 
                                          distance ="wasserstein", adaptive_tuning=0 ,K=5)
        dtw_tda_distance =  alpha*DTW_dis + (1-alpha)*tda_dissim   
        clustering = AgglomerativeClustering(n_clusters=k, affinity='precomputed',linkage='average')
        clustering.fit(dtw_tda_distance)
        label_Agg = clustering.labels_        
        result[dimension][delay] = adjusted_rand_score(y,label_Agg)
        
result_km = np.zeros((20,40), dtype = float, order = 'C')
for dimension in range(2,11):
    for delay in range(1,5):
        alpha = 0.025
        tda_dissim = TDATS.timeseries_tda(x, m = dimension, delay = delay, H=1, 
                                          distance ="wasserstein", adaptive_tuning=0 ,K=5)
        dtw_tda_distance =  alpha*DTW_dis + (1-alpha)*tda_dissim   
        label2 = kMedoids( dtw_tda_distance ,k, tmax=10000,init_centroids=1 )
        label2=label2.T
        result_km[dimension][delay] = adjusted_rand_score(y,label2.tolist()[0])